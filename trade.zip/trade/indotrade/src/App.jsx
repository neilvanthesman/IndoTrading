import './App.css'
import 'swiper/css';
import 'swiper/css/autoplay';

import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Footer from './components/Footer';
import ProductShowcase from './components/ProductShowcase';

export default function App() {
  return (
    <div className="font-sans">
      <Navbar />
      <Hero />
      <ProductShowcase/>
      <Footer />
    </div>
  );
}
