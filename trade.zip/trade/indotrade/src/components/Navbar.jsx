import { useState, useEffect } from 'react';

export default function Navbar() {
  const [isSticky, setSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setSticky(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`nav ${isSticky ? 'sticky' : ''}`}>
      <div className="nav-container">
        <div className="logo"><img src="https://resources.indotrading.com/frontend/images/logo-lg.png?v=6" alt="" /></div>

        <input
          type="text"
          placeholder="Ketik kebutuhan Anda"
          className="nav-search"
        />

        <div className="nav-buttons">
          <button className="login">Login</button>
          <button className="register">Register</button>
        </div>
      </div>
    </nav>
  );
}
