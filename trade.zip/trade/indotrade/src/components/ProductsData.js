export const categories = [
  {
    name: 'KONSTRUKSI DAN PROPERTI',
    image: 'https://image1ws.indotrading.com/s3/webp/category/w133-h291/77_konstruksi%20dan%20properti.png',
    products: [
      { name: 'Spray', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Panel', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
      { name: 'Lampu', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Radio', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Speaker', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Pipa Gas', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Handle Jendela', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg    ' },
      { name: 'Camera', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Semen Instan', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
    ]
  },{
    name: 'MEKANIK DAN SUKU CADANG',
    image: 'https://image1ws.indotrading.com/s3/webp/category/w133-h291/728_alat%20mekanik%20dan%20suku%20cadang.png',
    products: [
      { name: 'Product 1', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Product 2', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
      { name: 'Product 3', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Product 4', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Product 5', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Product 6', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Product 7', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg    ' },
      { name: 'Product 8', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Product 9', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
    ]
  },{
    name: 'ALAT PELINDUNG',
    image: 'https://image1ws.indotrading.com/s3/webp/category/w133-h291/97_alat%20pelindung%20diri-1.png',
    products: [
      { name: 'Spray', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Panel', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
      { name: 'Lampu', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Radio', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Speaker', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Pipa Gas', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Handle Jendela', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg    ' },
      { name: 'Camera', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Semen Instan', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
    ]
  },{
    name: 'ALAT UKUR DAN SURVEY',
    image: 'https://image1ws.indotrading.com/s3/webp/category/w133-h291/99_alat%20ukur%20dan%20survey.png',
    products: [
      { name: 'Spray', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Panel', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
      { name: 'Lampu', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Radio', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Speaker', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Pipa Gas', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4364_sprinkler.jpg' },
      { name: 'Handle Jendela', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg    ' },
      { name: 'Camera', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/17071_jual%20fire%20suppression%20system.jpg' },
      { name: 'Semen Instan', image: 'https://image1ws.indotrading.com/s3/webp/category/w100-h100/4359_lifeboat.jpg' },
    ]
  }
];
