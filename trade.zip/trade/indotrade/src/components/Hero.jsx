import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/autoplay';

import { Autoplay } from 'swiper/modules';

export default function Hero() {
  const categories = ['Supplier Alat Berat', 'Supplier Alat Elektro', 'Supplier Alat Industri', 
                      'Supplier Alat Mekanik', 'Supplier Alat Pelindung', 'Supplier Alat Ukur'
                    , 'Supplier Bahan Kimia'];

  const banners = [
    'https://resources.indotrading.com/mobile/content/images/adminbanner/slide4-indo.png',
    'https://resources.indotrading.com/mobile/content/images/adminbanner/slide3-indo.jpg',
    'https://resources.indotrading.com/mobile/content/images/adminbanner/slide1-indo.jpg',
  ];

  return (
    <section className="hero">
      <div className="hero-categories">
        {categories.map((cat, index) => (
          <div key={index} className="category-item">
            {cat}
          </div>
        ))}
      </div>

      <div className="hero-banner">
        <Swiper
          modules={[Autoplay]}
          autoplay={{ delay: 3000, disableOnInteraction: false }}
          loop={true}
          spaceBetween={20}
        >
          {banners.map((url, i) => (
            <SwiperSlide key={i}>
              <img src={url} alt={`Banner ${i + 1}`} className="carousel-image" />
            </SwiperSlide>
          ))}
        </Swiper>
      </div>
    </section>
  );
}
