export default function Footer() {
  return (
    <footer>
      <div className="container">
        <div className="footer-top">
          <div>
            <img src="https://resources.indotrading.com/frontend/images/logo-lg.png?v=6" alt="" />
            <h3>Pusat Supplier, Distributor, Importir dan Bisnis Direktori Indonesia</h3>
            <p>Direktori Bisnis Supplier Terbesar di Indonesia.

Segera Daftarkan perusahaan anda dan dapatkan akses ke informasi projek, tender dan dapatkan website gratis untuk perusahaan anda.</p>
          </div>
          <div>
            <h4>KONTAK</h4>
            <p>Email: <a href="mailto:support@indotrading.co.id">support@indotrading.co.id</a></p>
            <p>Telp: <a href="tel:+622112345678">(021) 12345678</a></p>
          </div>
          <div>
            <h4>LINKS</h4>
            <a href="https://www.indotrading.com/askquestion.aspx">FAQ</a>
            <a href="https://www.indotrading.com/termandcondition.aspx">Syarat & Ketentuan</a>
          </div>
        </div>
        <div className="footer-bottom">© 2025  Indotrading - Indonesia B2B Marketplace Direktori Bisnis Indonesia All Rights Reserved.</div>
      </div>
    </footer>
  );
}
