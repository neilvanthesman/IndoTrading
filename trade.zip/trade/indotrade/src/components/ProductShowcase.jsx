import { categories } from './ProductsData';

export default function ProductShowcase() {
  return (
    <section className="product-wrapper">
        <div className="product-showcase">
        {categories.map((cat, idx) => (
            <div key={idx} className="category-block">
            <div className="category-info">
                <h3>{cat.name}</h3>
                <img src={cat.image} alt={cat.name} />
            </div>
            <div className="product-items">
                {cat.products.map((prod, i) => (
                <div key={i} className="product-card">
                    <img src={prod.image} alt={prod.name} />
                    <p>{prod.name}</p>
                </div>
                ))}
            </div>
            </div>
        ))}
        </div>
    </section>
  );
}
